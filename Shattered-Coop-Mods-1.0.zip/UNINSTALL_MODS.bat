@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0app\desktop-4.0.1.jar" goto :failed
if not exist "%~dp0app\Shattered Pixel Dungeon.before-mods.cfg" goto :original
findstr /i /c:"ModLoader" /c:"CoopLauncher" "%~dp0app\Shattered Pixel Dungeon.before-mods.cfg" >nul
if not errorlevel 1 goto :original
findstr /c:"app.mainclass=com.shatteredpixel.shatteredpixeldungeon.desktop.DesktopLauncher" "%~dp0app\Shattered Pixel Dungeon.before-mods.cfg" >nul
if errorlevel 1 goto :original
copy /b /y "%~dp0app\Shattered Pixel Dungeon.before-mods.cfg" "%~dp0app\Shattered Pixel Dungeon.cfg" >nul
if errorlevel 1 goto :failed
goto :done
:original
if not exist "%~dp0app\Shattered Pixel Dungeon.original-4.0.1g.cfg" goto :failed
copy /b /y "%~dp0app\Shattered Pixel Dungeon.original-4.0.1g.cfg" "%~dp0app\Shattered Pixel Dungeon.cfg" >nul
if errorlevel 1 goto :failed
:done
echo Original launcher configuration restored. Saves and mod files are kept.
if /i not "%~1"=="--quiet" pause
exit /b 0
:failed
echo Could not restore the launcher. Extract all files from the mod ZIP again.
if /i not "%~1"=="--quiet" pause
exit /b 1
