@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0Shattered Pixel Dungeon.exe" goto :wrong_folder
if not exist "%~dp0runtime\bin\server\jvm.dll" goto :wrong_folder
if not exist "%~dp0app\desktop-4.0.1.jar" goto :wrong_folder
if not exist "%~dp0app\Shattered-ModLoader.jar" goto :missing
if not exist "%~dp0app\Shattered-ModLoader.cfg" goto :missing
if not exist "%~dp0app\Shattered Pixel Dungeon.original-4.0.1g.cfg" goto :missing
if exist "%~dp0app\Shattered Pixel Dungeon.before-mods.cfg" goto :install
if not exist "%~dp0app\Shattered Pixel Dungeon.cfg" goto :install
copy /b /y "%~dp0app\Shattered Pixel Dungeon.cfg" "%~dp0app\Shattered Pixel Dungeon.before-mods.cfg" >nul
if errorlevel 1 goto :failed
:install
copy /b /y "%~dp0app\Shattered-ModLoader.cfg" "%~dp0app\Shattered Pixel Dungeon.cfg" >nul
if errorlevel 1 goto :failed
if not exist "%~dp0mods" mkdir "%~dp0mods"
echo Installed. Start the usual Shattered Pixel Dungeon.exe.
echo Co-op: keep mods\shattered-coop.jar. Vanilla: move that JAR out of mods.
if /i not "%~1"=="--quiet" pause
exit /b 0
:wrong_folder
echo Extract ALL files beside Shattered Pixel Dungeon.exe, for game v4.0.1g.
goto :failed
:missing
echo Loader files are missing. Extract ALL files from the ZIP again.
:failed
echo Installation failed. Close the game and check that this folder is writable.
if /i not "%~1"=="--quiet" pause
exit /b 1
